// Form page after Stripe payment
