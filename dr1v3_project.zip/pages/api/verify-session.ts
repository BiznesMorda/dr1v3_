// Verifies session after Stripe payment
