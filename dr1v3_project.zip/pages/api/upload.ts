// Cloudinary image upload handler
