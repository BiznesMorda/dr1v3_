// Stripe Checkout Session handler
