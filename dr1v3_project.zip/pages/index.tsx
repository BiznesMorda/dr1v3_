// Landing page with dark purple theme
